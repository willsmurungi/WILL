#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split


# In[2]:


df=pd.read_csv("C:\\Users\\Murungi wilson\\Desktop\\AI_PRAC\\03_Clustering_Marketing.csv")
df


# In[3]:


df.head()


# In[4]:


df.tail()


# In[5]:


x=df['NumberOffriends'].array.reshape(-1,1)
x


# In[6]:


y=df['sex']
y


# In[7]:


#splitting the data
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)


# In[8]:


model=LinearRegression()
model.fit(x_train,y_train)


# In[9]:


score=model.score(x_train,y_train)
score


# In[10]:


model.coef_


# In[11]:


model.intercept_


# FINE TUNING

# In[12]:


#Defining parameters
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import mean_squared_error


# In[13]:


param_grid={
    'copy_X':[True,False], 
    'fit_intercept':[True,False], 
    'n_jobs':[True,False],
    'positive':[True,False]

}


# In[14]:


#performing grid with cross_validation
grid_search=GridSearchCV(model,param_grid,cv=5,scoring='neg_mean_squared_error')
grid_search.fit(x_train,y_train)


# In[15]:


#Best model
best_model=grid_search.best_estimator_
best_model


# In[16]:


best_score=model.score(x_test,y_test)
best_score


# In[17]:


y_pred=best_model.predict(x_test)
y_pred


# In[18]:


mse=mean_squared_error(y_test,y_pred)
mse


# In[ ]:




