#!/usr/bin/env python
# coding: utf-8

# MURUNGI WILSON/U/MMU/BSSE/01802.
# FINE TUNING LOGISTIC REGRESSION

# In[1]:


#Required libraries
from sklearn.datasets import make_classification
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
import pandas as pd


# In[2]:


df=pd.read_csv("C:\\Users\\Murungi wilson\\03_Clus  tering_Marketing.csv")
df


# In[3]:


df.head()


# In[4]:


df.tail()


# In[5]:


x=df['NumberOffriends'].array.reshape(-1,1)
x


# In[6]:


y=df['sex']
y


# In[7]:


#splitting the data
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)


# In[8]:


x_train.shape


# In[9]:


model=LogisticRegression()
model.fit(x_train,y_train)


# In[10]:


y_pred=model.predict(x_test)
y_pred


# In[11]:


score=model.score(x_train,y_train)
score


# FINE TUNING

# In[12]:


#Defining parameters
param_grid={
    'penalty':['l1','l2'],
    'C':[0.001,0.01,0.1,1,10,100],
    'solver':['liblinear','saga']
}


# In[13]:


#performing grid with cross_validation
grid_search=GridSearchCV(estimator=model,param_grid=param_grid,cv=5,n_jobs=-1)
grid_search.fit(x_train,y_train)


# In[14]:


#best parameters and best score
best_param=grid_search.best_params_
grid_search


# In[15]:


best_score=grid_search.best_score_
best_score


# In[16]:


#evaluating the performance
score=grid_search.score(x_test,y_test)
score


# In[18]:


y_pred=model.predict(x_test)
y_pred


# In[ ]:




